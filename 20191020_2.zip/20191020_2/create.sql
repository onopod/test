118.27.18.94

create table data (
dtm timestamp,
power float,
vol float,
elec float,
id varchar(20),
primary key(id, dtm)
);

load data local infile 'out.tsv'
into table data;

